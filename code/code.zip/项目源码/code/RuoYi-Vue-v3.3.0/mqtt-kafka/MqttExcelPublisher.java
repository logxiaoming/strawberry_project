import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.eclipse.paho.client.mqttv3.*;

import org.eclipse.paho.client.mqttv3.MqttClientPersistence;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;

public class MqttExcelPublisher {

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d H:mm:ss");

    public static void main(String[] args) throws Exception {
        String mqttBrokerUrl = "tcp://localhost:1883"; // 修改为你的MQTT服务器IP地址
        String mqttTopic = "mqtt-topic";
        String excelFilePath = "excel1.xlsx"; // Excel 文件路径

        // 从 Excel 文件读取数据并发布到 MQTT 主题
        publishDataFromExcelToMqtt(mqttBrokerUrl, mqttTopic, excelFilePath);
    }

    public static void publishDataFromExcelToMqtt(String mqttBrokerUrl, String mqttTopic, String excelFilePath) throws MqttException, IOException, InterruptedException {
        Path excelPath = Paths.get(excelFilePath);
        FileInputStream fis = new FileInputStream(excelPath.toFile());

        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheetAt(0); // 假设数据在第一个工作表

        List<String> dataRows = new ArrayList<>();
        Iterator<Row> rowIterator = sheet.iterator();

        // 读取表头以获取列的索引
        Row headerRow = rowIterator.next();
        Map<String, Integer> headerMap = getHeaderMap(headerRow);

        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (isRowEmpty(row)) {
                continue; // 跳过空行
            }
            String dataRow = getDataRow(row, headerMap);
            dataRows.add(dataRow);
        }
        fis.close();
        workbook.close();

        // 设置 MQTT 客户端
        MqttClientPersistence persistence = new MemoryPersistence();
        MqttClient mqttClient = new MqttClient(mqttBrokerUrl, MqttClient.generateClientId(), persistence);
        MqttConnectOptions connOpts = new MqttConnectOptions();
        connOpts.setCleanSession(true);
        mqttClient.connect(connOpts);

        for (String dataRow : dataRows) {
            MqttMessage message = new MqttMessage(dataRow.getBytes());
            mqttClient.publish(mqttTopic, message);

            System.out.println("Message published to MQTT topic: " + mqttTopic + " with content: " + dataRow);

            // 等待2秒钟
            Thread.sleep(2000);
        }

        // 断开 MQTT 客户端
        mqttClient.disconnect();
        mqttClient.close();
    }

    private static boolean isRowEmpty(Row row) {
        for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
            Cell cell = row.getCell(c);
            if (cell != null && cell.getCellType() != CellType.BLANK) {
                return false;
            }
        }
        return true;
    }

    private static Map<String, Integer> getHeaderMap(Row headerRow) {
        Map<String, Integer> headerMap = new HashMap<>();
        Iterator<Cell> cellIterator = headerRow.cellIterator();
        while (cellIterator.hasNext()) {
            Cell cell = cellIterator.next();
            headerMap.put(cell.getStringCellValue(), cell.getColumnIndex());
        }
        return headerMap;
    }

    private static String getDataRow(Row row, Map<String, Integer> headerMap) {
        StringBuilder content = new StringBuilder();
        for (Map.Entry<String, Integer> entry : headerMap.entrySet()) {
            Cell cell = row.getCell(entry.getValue());
            String cellValue = getCellValue(cell);
            content.append(entry.getKey()).append(": ").append(cellValue).append(", ");
        }
        // 移除最后一个逗号和空格
        if (content.length() > 2) {
            content.setLength(content.length() - 2);
        }
        return content.toString();
    }

    private static String getCellValue(Cell cell) {
        if (cell == null) return "";
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return dateFormat.format(cell.getDateCellValue());
                } else {
                    return String.valueOf(cell.getNumericCellValue());
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            default:
                return "";
        }
    }
}
