package com.ruoyi.web.controller.output;

import java.util.List;

import com.ruoyi.test.domain.StrawberryHouse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.output.domain.SvrPredict;
import com.ruoyi.output.service.ISvrPredictService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * outputPredictController
 * 
 * @author jxh
 * @date 2024-07-25
 */
@RestController
@RequestMapping("/output/predict")
public class SvrPredictController extends BaseController
{
    @Autowired
    private ISvrPredictService svrPredictService;

    /**
     * 查询outputPredict列表
     */
    @PreAuthorize("@ss.hasPermi('output:predict:list')")
    @GetMapping("/list")
    public TableDataInfo list(SvrPredict svrPredict)
    {
        startPage();
        List<SvrPredict> list = svrPredictService.selectSvrPredictList(svrPredict);
        return getDataTable(list);
    }

    /**
     * 导出outputPredict列表
     */
    @PreAuthorize("@ss.hasPermi('output:predict:export')")
    @Log(title = "outputPredict", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(SvrPredict svrPredict)
    {
        List<SvrPredict> list = svrPredictService.selectSvrPredictList(svrPredict);
        ExcelUtil<SvrPredict> util = new ExcelUtil<SvrPredict>(SvrPredict.class);
        return util.exportExcel(list, "predict");
    }

    /**
     * 获取outputPredict详细信息
     */
    @PreAuthorize("@ss.hasPermi('output:predict:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return AjaxResult.success(svrPredictService.selectSvrPredictById(id));
    }

    /**
     * 新增outputPredict
     */
    @PreAuthorize("@ss.hasPermi('output:predict:add')")
    @Log(title = "outputPredict", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SvrPredict svrPredict)
    {
        return toAjax(svrPredictService.insertSvrPredict(svrPredict));
    }

    /**
     * 修改outputPredict
     */
    @PreAuthorize("@ss.hasPermi('output:predict:edit')")
    @Log(title = "outputPredict", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SvrPredict svrPredict)
    {
        return toAjax(svrPredictService.updateSvrPredict(svrPredict));
    }

    /**
     * 删除outputPredict
     */
    @PreAuthorize("@ss.hasPermi('output:predict:remove')")
    @Log(title = "outputPredict", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(svrPredictService.deleteSvrPredictByIds(ids));
    }
    @GetMapping("/getOutput")
    public List<SvrPredict> getOutput(
            @RequestParam("id") String id) {
        List<SvrPredict> output = svrPredictService.selectdata(id);
        return output;
    }
}
