package com.ruoyi.web.controller.exceptionTest;

import java.util.Date;
import java.util.List;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.exceptionTest.domain.Exception;
import com.ruoyi.exceptionTest.service.IExceptionService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * exceptionController
 * 
 * @author jxh
 * @date 2024-07-24
 */
@RestController
@RequestMapping("/exception/exception")
public class ExceptionController extends BaseController
{
    @Autowired
    private IExceptionService exceptionService;

    /**
     * 查询exception列表
     */
    @PreAuthorize("@ss.hasPermi('exception:exception:list')")
    @GetMapping("/list")
    public TableDataInfo list(Exception exception)
    {
        startPage();
        List<Exception> list = exceptionService.selectExceptionList(exception);
        return getDataTable(list);
    }

    /**
     * 导出exception列表
     */
    @PreAuthorize("@ss.hasPermi('exception:exception:export')")
    @Log(title = "exception", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(Exception exception)
    {
        List<Exception> list = exceptionService.selectExceptionList(exception);
        ExcelUtil<Exception> util = new ExcelUtil<Exception>(Exception.class);
        return util.exportExcel(list, "exception");
    }

    /**
     * 获取exception详细信息
     */
    @PreAuthorize("@ss.hasPermi('exception:exception:query')")
    @GetMapping(value = "/{currentDatetime}")
    public AjaxResult getInfo(@PathVariable("currentDatetime") Date currentDatetime)
    {
        return AjaxResult.success(exceptionService.selectExceptionById(currentDatetime));
    }

    /**
     * 新增exception
     */
    @PreAuthorize("@ss.hasPermi('exception:exception:add')")
    @Log(title = "exception", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Exception exception)
    {
        return toAjax(exceptionService.insertException(exception));
    }

    /**
     * 修改exception
     */
    @PreAuthorize("@ss.hasPermi('exception:exception:edit')")
    @Log(title = "exception", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Exception exception)
    {
        return toAjax(exceptionService.updateException(exception));
    }

    /**
     * 删除exception
     */
    @PreAuthorize("@ss.hasPermi('exception:exception:remove')")
    @Log(title = "exception", businessType = BusinessType.DELETE)
	@DeleteMapping("/{currentDatetimes}")
    public AjaxResult remove(@PathVariable String[] currentDatetimes)
    {
        return toAjax(exceptionService.deleteExceptionByIds(currentDatetimes));
    }
}
